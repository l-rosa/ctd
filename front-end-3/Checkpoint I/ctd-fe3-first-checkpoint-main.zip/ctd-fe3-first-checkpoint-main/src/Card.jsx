//Este componente deverá receber dados por Props e mostrar as Informações em Tela

export function Card () {
  return (
    <div>

    </div>
  )
}