
// Aqui você irá escrever as suas funções de Validação, para verificar se o Formulário foi preenchido corretamente

function App() {
  // Aqui você irá criar os Estados para manipular os Inputs


  return (
    <div className="App">
     <h1>Carga de estudiantes</h1>
     <form>
      {/* Comece a desenvolver o seu Código por aqui :) */}
     </form>
    </div>
  )
}

export default App